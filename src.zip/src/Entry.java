
public interface Entry {
	public static String type="Entry";
}
